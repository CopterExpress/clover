#ifndef _ROS_mission_MissionState_h
#define _ROS_mission_MissionState_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"

namespace mission
{

  class MissionState : public ros::Msg
  {
    public:
      typedef bool _running_type;
      _running_type running;
      typedef const char* _mission_json_type;
      _mission_json_type mission_json;
      typedef const char* _outcome_type;
      _outcome_type outcome;

    MissionState():
      running(0),
      mission_json(""),
      outcome("")
    {
    }

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      union {
        bool real;
        uint8_t base;
      } u_running;
      u_running.real = this->running;
      *(outbuffer + offset + 0) = (u_running.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->running);
      uint32_t length_mission_json = strlen(this->mission_json);
      varToArr(outbuffer + offset, length_mission_json);
      offset += 4;
      memcpy(outbuffer + offset, this->mission_json, length_mission_json);
      offset += length_mission_json;
      uint32_t length_outcome = strlen(this->outcome);
      varToArr(outbuffer + offset, length_outcome);
      offset += 4;
      memcpy(outbuffer + offset, this->outcome, length_outcome);
      offset += length_outcome;
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      union {
        bool real;
        uint8_t base;
      } u_running;
      u_running.base = 0;
      u_running.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->running = u_running.real;
      offset += sizeof(this->running);
      uint32_t length_mission_json;
      arrToVar(length_mission_json, (inbuffer + offset));
      offset += 4;
      for(unsigned int k= offset; k< offset+length_mission_json; ++k){
          inbuffer[k-1]=inbuffer[k];
      }
      inbuffer[offset+length_mission_json-1]=0;
      this->mission_json = (char *)(inbuffer + offset-1);
      offset += length_mission_json;
      uint32_t length_outcome;
      arrToVar(length_outcome, (inbuffer + offset));
      offset += 4;
      for(unsigned int k= offset; k< offset+length_outcome; ++k){
          inbuffer[k-1]=inbuffer[k];
      }
      inbuffer[offset+length_outcome-1]=0;
      this->outcome = (char *)(inbuffer + offset-1);
      offset += length_outcome;
     return offset;
    }

    const char * getType(){ return "mission/MissionState"; };
    const char * getMD5(){ return "1b65ef68689368d73bdb412a2b50166f"; };

  };

}
#endif