#ifndef _ROS_misc_CpuUsage_h
#define _ROS_misc_CpuUsage_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"

namespace misc
{

  class CpuUsage : public ros::Msg
  {
    public:
      uint32_t cpu_usage_length;
      typedef float _cpu_usage_type;
      _cpu_usage_type st_cpu_usage;
      _cpu_usage_type * cpu_usage;

    CpuUsage():
      cpu_usage_length(0), cpu_usage(NULL)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      *(outbuffer + offset + 0) = (this->cpu_usage_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->cpu_usage_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->cpu_usage_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->cpu_usage_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->cpu_usage_length);
      for( uint32_t i = 0; i < cpu_usage_length; i++){
      union {
        float real;
        uint32_t base;
      } u_cpu_usagei;
      u_cpu_usagei.real = this->cpu_usage[i];
      *(outbuffer + offset + 0) = (u_cpu_usagei.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_cpu_usagei.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_cpu_usagei.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_cpu_usagei.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->cpu_usage[i]);
      }
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      uint32_t cpu_usage_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      cpu_usage_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      cpu_usage_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      cpu_usage_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->cpu_usage_length);
      if(cpu_usage_lengthT > cpu_usage_length)
        this->cpu_usage = (float*)realloc(this->cpu_usage, cpu_usage_lengthT * sizeof(float));
      cpu_usage_length = cpu_usage_lengthT;
      for( uint32_t i = 0; i < cpu_usage_length; i++){
      union {
        float real;
        uint32_t base;
      } u_st_cpu_usage;
      u_st_cpu_usage.base = 0;
      u_st_cpu_usage.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_st_cpu_usage.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_st_cpu_usage.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_st_cpu_usage.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->st_cpu_usage = u_st_cpu_usage.real;
      offset += sizeof(this->st_cpu_usage);
        memcpy( &(this->cpu_usage[i]), &(this->st_cpu_usage), sizeof(float));
      }
     return offset;
    }

    const char * getType(){ return "misc/CpuUsage"; };
    const char * getMD5(){ return "b1b16e482c44390280f30cb390418d38"; };

  };

}
#endif