#ifndef _ROS_SERVICE_SetRatesYaw_h
#define _ROS_SERVICE_SetRatesYaw_h
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"

namespace clever
{

static const char SETRATESYAW[] = "clever/SetRatesYaw";

  class SetRatesYawRequest : public ros::Msg
  {
    public:
      typedef float _pitch_rate_type;
      _pitch_rate_type pitch_rate;
      typedef float _roll_rate_type;
      _roll_rate_type roll_rate;
      typedef float _yaw_type;
      _yaw_type yaw;
      typedef float _thrust_type;
      _thrust_type thrust;
      typedef const char* _frame_id_type;
      _frame_id_type frame_id;
      typedef bool _update_frame_type;
      _update_frame_type update_frame;
      typedef bool _auto_arm_type;
      _auto_arm_type auto_arm;

    SetRatesYawRequest():
      pitch_rate(0),
      roll_rate(0),
      yaw(0),
      thrust(0),
      frame_id(""),
      update_frame(0),
      auto_arm(0)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      union {
        float real;
        uint32_t base;
      } u_pitch_rate;
      u_pitch_rate.real = this->pitch_rate;
      *(outbuffer + offset + 0) = (u_pitch_rate.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_pitch_rate.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_pitch_rate.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_pitch_rate.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->pitch_rate);
      union {
        float real;
        uint32_t base;
      } u_roll_rate;
      u_roll_rate.real = this->roll_rate;
      *(outbuffer + offset + 0) = (u_roll_rate.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_roll_rate.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_roll_rate.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_roll_rate.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->roll_rate);
      union {
        float real;
        uint32_t base;
      } u_yaw;
      u_yaw.real = this->yaw;
      *(outbuffer + offset + 0) = (u_yaw.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_yaw.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_yaw.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_yaw.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->yaw);
      union {
        float real;
        uint32_t base;
      } u_thrust;
      u_thrust.real = this->thrust;
      *(outbuffer + offset + 0) = (u_thrust.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_thrust.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_thrust.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_thrust.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->thrust);
      uint32_t length_frame_id = strlen(this->frame_id);
      varToArr(outbuffer + offset, length_frame_id);
      offset += 4;
      memcpy(outbuffer + offset, this->frame_id, length_frame_id);
      offset += length_frame_id;
      union {
        bool real;
        uint8_t base;
      } u_update_frame;
      u_update_frame.real = this->update_frame;
      *(outbuffer + offset + 0) = (u_update_frame.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->update_frame);
      union {
        bool real;
        uint8_t base;
      } u_auto_arm;
      u_auto_arm.real = this->auto_arm;
      *(outbuffer + offset + 0) = (u_auto_arm.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->auto_arm);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      union {
        float real;
        uint32_t base;
      } u_pitch_rate;
      u_pitch_rate.base = 0;
      u_pitch_rate.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_pitch_rate.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_pitch_rate.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_pitch_rate.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->pitch_rate = u_pitch_rate.real;
      offset += sizeof(this->pitch_rate);
      union {
        float real;
        uint32_t base;
      } u_roll_rate;
      u_roll_rate.base = 0;
      u_roll_rate.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_roll_rate.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_roll_rate.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_roll_rate.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->roll_rate = u_roll_rate.real;
      offset += sizeof(this->roll_rate);
      union {
        float real;
        uint32_t base;
      } u_yaw;
      u_yaw.base = 0;
      u_yaw.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_yaw.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_yaw.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_yaw.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->yaw = u_yaw.real;
      offset += sizeof(this->yaw);
      union {
        float real;
        uint32_t base;
      } u_thrust;
      u_thrust.base = 0;
      u_thrust.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_thrust.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_thrust.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_thrust.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->thrust = u_thrust.real;
      offset += sizeof(this->thrust);
      uint32_t length_frame_id;
      arrToVar(length_frame_id, (inbuffer + offset));
      offset += 4;
      for(unsigned int k= offset; k< offset+length_frame_id; ++k){
          inbuffer[k-1]=inbuffer[k];
      }
      inbuffer[offset+length_frame_id-1]=0;
      this->frame_id = (char *)(inbuffer + offset-1);
      offset += length_frame_id;
      union {
        bool real;
        uint8_t base;
      } u_update_frame;
      u_update_frame.base = 0;
      u_update_frame.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->update_frame = u_update_frame.real;
      offset += sizeof(this->update_frame);
      union {
        bool real;
        uint8_t base;
      } u_auto_arm;
      u_auto_arm.base = 0;
      u_auto_arm.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->auto_arm = u_auto_arm.real;
      offset += sizeof(this->auto_arm);
     return offset;
    }

    const char * getType(){ return SETRATESYAW; };
    const char * getMD5(){ return "cce6280cbda465bc3c3546baa5bbe847"; };

  };

  class SetRatesYawResponse : public ros::Msg
  {
    public:
      typedef bool _success_type;
      _success_type success;
      typedef const char* _message_type;
      _message_type message;

    SetRatesYawResponse():
      success(0),
      message("")
    {
    }

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      union {
        bool real;
        uint8_t base;
      } u_success;
      u_success.real = this->success;
      *(outbuffer + offset + 0) = (u_success.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->success);
      uint32_t length_message = strlen(this->message);
      varToArr(outbuffer + offset, length_message);
      offset += 4;
      memcpy(outbuffer + offset, this->message, length_message);
      offset += length_message;
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      union {
        bool real;
        uint8_t base;
      } u_success;
      u_success.base = 0;
      u_success.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->success = u_success.real;
      offset += sizeof(this->success);
      uint32_t length_message;
      arrToVar(length_message, (inbuffer + offset));
      offset += 4;
      for(unsigned int k= offset; k< offset+length_message; ++k){
          inbuffer[k-1]=inbuffer[k];
      }
      inbuffer[offset+length_message-1]=0;
      this->message = (char *)(inbuffer + offset-1);
      offset += length_message;
     return offset;
    }

    const char * getType(){ return SETRATESYAW; };
    const char * getMD5(){ return "937c9679a518e3a18d831e57125ea522"; };

  };

  class SetRatesYaw {
    public:
    typedef SetRatesYawRequest Request;
    typedef SetRatesYawResponse Response;
  };

}
#endif
